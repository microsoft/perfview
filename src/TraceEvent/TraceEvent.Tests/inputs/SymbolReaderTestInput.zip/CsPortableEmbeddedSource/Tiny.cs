class C{int X=>0;}
