﻿using System;

namespace CsPortableEmbeddedSource
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello from CsPortableEmbeddedSource!");
        }
    }
}
