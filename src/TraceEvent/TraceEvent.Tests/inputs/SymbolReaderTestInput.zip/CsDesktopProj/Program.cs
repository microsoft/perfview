﻿using System;

namespace CsDesktopProj
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello from CsDesktopProj");
        }
    }
}
