﻿using System;

namespace CsPortablePdb1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello from CsPortablePdb1!");
        }
    }
}
