This directory contains inputs to the SymbolReaderTests. If you ever want to recreate that .zip file, follow these steps:

1. Extract the .zip to C:\PerfViewTestData
2. Make any changes you want to make
3. git init
4. git clean -ndX -- this is a dry run, make sure the files that would be deleted are fine
5. git clean -fdX
6. zip up the folder
